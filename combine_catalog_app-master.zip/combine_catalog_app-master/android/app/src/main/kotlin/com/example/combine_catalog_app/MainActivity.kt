package com.example.combine_catalog_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
